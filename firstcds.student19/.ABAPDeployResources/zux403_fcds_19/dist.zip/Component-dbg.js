sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend("firstcds.student19.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
