sap.ui.define([
	"student19sap.training./helloworld/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
